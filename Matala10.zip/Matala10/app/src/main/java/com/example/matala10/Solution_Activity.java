package com.example.matala10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Solution_Activity extends AppCompatActivity {
    Button btn_1, btn_2;
    TextView tv1, tv2, tv3;
    WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solution);
        btn_1 = findViewById(R.id.btn_1);
        btn_2 = findViewById(R.id.btn_2);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
        wv = findViewById(R.id.wv);
        double result1 = 0.0;
        double result2 = 0.0;
        Intent intent = getIntent();
        double a = intent.getDoubleExtra("a", 0.0);
        double b = intent.getDoubleExtra("b", 0.0);
        double c = intent.getDoubleExtra("c", 0.0);
        if ((b*4*a)>(b*b)){
            Toast.makeText(this, "There is no solution", Toast.LENGTH_SHORT).show();
        }
        else if (b*4*a==b*b){
            Toast.makeText(this, "There is only one solution", Toast.LENGTH_SHORT).show();
            result1 = -b / (2*a);
            tv2.setText(String.valueOf(result1));
        }
        else{
            Toast.makeText(this, "There is two solution", Toast.LENGTH_SHORT).show();
            result1 = (-b + Math.sqrt(b*b-(4*a*c)))/(2*a);
            result2 = (-b - Math.sqrt(b*b-(4*a*c)))/(2*a);
        }
    }

    public void back(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void Go(View view) {
        String url = tv1.getText().toString();
        wv.loadUrl(url);
    }
}
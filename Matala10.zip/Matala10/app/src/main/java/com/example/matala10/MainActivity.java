package com.example.matala10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    Button btn1, btn2;
    EditText et1, et2, et3;
    Boolean bool1 = false;
    Boolean bool2 = false;
    Boolean bool3 = false;
    double a;
    double b;
    double c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn1);
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);
    }

    public void random_numbers(View view){
            Random rnd = new Random();
            a = (float)rnd.nextInt(9)+1;
            b = (float)rnd.nextInt(9)+1;
            c = (float)rnd.nextInt(9)+1;
            et1.setText(String.valueOf(a));
            et2.setText(String.valueOf(b));
            et3.setText(String.valueOf(c));
    }

    public void go(View view) {
        a = Double.parseDouble(et1.getText().toString());
        b = Double.parseDouble(et2.getText().toString());
        c = Double.parseDouble(et3.getText().toString());
        Intent intent = new Intent(this, Solution_Activity.class);
        intent.putExtra("a", a);
        intent.putExtra("b", b);
        intent.putExtra("c", c);
        startActivity(intent);
    }
}